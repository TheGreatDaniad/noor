package main

const (
	USERS_FILE_PATH  = "users.yaml"
	CONFIG_FILE_PATH = "./config.yaml"
)
